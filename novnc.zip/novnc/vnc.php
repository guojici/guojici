<?php
require_once __DIR__ . '/../config/helper.php';
require_auth();
session_write_close();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user_id = auth_id();

$host = Database::fetch("SELECT * FROM hosts WHERE id = ? AND user_id = ?", [$id, $user_id]);
if (!$host) {
    die('主机不存在');
}

if (empty($host['vm_name'])) {
    die('非KVM主机');
}

$vm_name = $host['vm_name'];

// 获取VNC配置
$kvm_cfg = config('kvm');
$ws_host = $kvm_cfg['public_domain'] ?? $_SERVER['HTTP_HOST'];
$ws_port = $kvm_cfg['novnc_port'] ?? 6080;
$vnc_host = $kvm_cfg['vnc_proxy_host'] ?? '127.0.0.1';

$vnc_port = 5900;
$vm_status = 'unknown';

if (kvm_is_enabled()) {
    try {
        $kvm = kvm_get_manager();
        $vm_status = $kvm->getVMPowerState($vm_name);
        
        if ($vm_status === 'running') {
            $vnc_display = $kvm->getVNCDisplay($vm_name);
            
            if (strpos($vnc_display, ':') === 0) {
                $vnc_port = 5900 + intval(substr($vnc_display, 1));
            } else if (is_numeric($vnc_display)) {
                $vnc_port = intval($vnc_display);
            }
        }
    } catch (Exception $e) {
        $vm_status = 'error';
    }
}

// noVNC直接连接到VNC服务器（通过WebSocket）
$novnc_path = '/assets/novnc/vnc.html';
$vnc_url = "wss://{$ws_host}:{$ws_port}/vnc/{$vm_name}?autoconnect=1";
$novnc_base = "https://{$ws_host}:{$ws_port}";
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VNC 控制台 - <?php echo e($vm_name); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { width: 100%; height: 100%; overflow: hidden; background: #1a1a2e; }
        #top-bar {
            height: 48px;
            background: linear-gradient(90deg, #1677ff, #69b1ff);
            color: #fff;
            display: flex;
            align-items: center;
            padding: 0 16px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px;
        }
        #top-bar .title { flex: 1; font-weight: 600; }
        #top-bar .status {
            font-size: 12px;
            padding: 4px 10px;
            border-radius: 12px;
            background: rgba(255,255,255,0.2);
            margin-right: 12px;
        }
        #top-bar .status.running { background: rgba(82, 196, 26, 0.3); }
        #top-bar .status.stopped { background: rgba(245, 63, 63, 0.3); }
        #top-bar .status.error { background: rgba(250, 173, 20, 0.3); }
        #top-bar .actions button {
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.3);
            color: #fff;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin-left: 8px;
        }
        #top-bar .actions button:hover { background: rgba(255,255,255,0.25); }
        #novnc-frame {
            width: 100%;
            height: calc(100% - 48px);
            border: none;
            display: block;
        }
        #loading {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: #fff;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        #loading .spinner {
            width: 40px;
            height: 40px;
            border: 3px solid rgba(255,255,255,0.2);
            border-top-color: #1677ff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div id="top-bar">
        <div class="title">🖥️ VNC 控制台 - <?php echo e($vm_name); ?></div>
        <span class="status <?php echo $vm_status; ?>" id="vm_status">
            状态: <?php echo $vm_status === 'running' ? '运行中' : ($vm_status === 'stopped' ? '已停止' : '未知'); ?>
        </span>
        <div class="actions">
            <button onclick="location.reload()">🔄 刷新</button>
            <button onclick="window.history.back()">← 返回</button>
        </div>
    </div>
    
    <div id="loading">
        <div class="spinner"></div>
        <div>正在加载 VNC 控制台...</div>
        <div style="font-size: 12px; color: rgba(255,255,255,0.6); margin-top: 8px;">
            虚拟机: <?php echo e($vm_name); ?>
        </div>
        <div style="font-size: 12px; color: rgba(255,255,255,0.6); margin-top: 4px;">
            VNC端口: <?php echo $vnc_port; ?>
        </div>
        <div style="font-size: 11px; color: rgba(255,255,255,0.4); margin-top: 4px;">
            状态: <?php echo $vm_status; ?>
        </div>
    </div>
    
    <?php if ($vm_status === 'running'): ?>
    <!-- 直接嵌入noVNC -->
    <iframe id="novnc-frame" 
            src="/novnc/vnc.html?host=<?php echo urlencode($ws_host); ?>&port=<?php echo $ws_port; ?>&autoconnect=true&resize=scale"
            style="width:100%; height:calc(100% - 48px); border:none;"
            allowfullscreen>
    </iframe>
    <?php else: ?>
    <div style="width:100%; height:calc(100% - 48px); display:flex; align-items:center; justify-content:center; color:#fff; background:#1a1a2e;">
        <div style="text-align:center;">
            <div style="font-size:48px; margin-bottom:16px;">⚠️</div>
            <div style="font-size:18px; margin-bottom:8px;">虚拟机未运行</div>
            <div style="font-size:14px; color:rgba(255,255,255,0.6);">请先启动虚拟机后再连接VNC</div>
            <button onclick="window.history.back()" style="margin-top:24px; padding:12px 24px; background:#1677ff; color:#fff; border:none; border-radius:6px; cursor:pointer;">
                返回
            </button>
        </div>
    </div>
    <?php endif; ?>
</body>
</html>
