#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/websockify.pid"
LOG_FILE="$SCRIPT_DIR/websockify.log"

echo "websockify 状态:"
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "  ✓ 运行中 (PID: $PID)"
        echo "  监听端口: 6080"
        echo ""
        echo "最近日志:"
        tail -10 "$LOG_FILE" 2>/dev/null
    else
        echo "  ✗ 未运行 (PID文件存在但进程不存在)"
    fi
else
    echo "  ✗ 未运行"
fi
