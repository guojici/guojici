#!/bin/bash
# noVNC + websockify 一键安装脚本
# 适用于 CentOS 7 / CentOS 8 / Ubuntu / Debian

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOKEN_DIR="$SCRIPT_DIR/tokens"
TOKEN_FILE="$TOKEN_DIR/tokens.conf"

echo "========================================"
echo "  noVNC + websockify 安装脚本"
echo "========================================"

# 1. 检查 Python
echo ""
echo "[1/5] 检查 Python..."
if command -v python3 &> /dev/null; then
    PYTHON=python3
    echo "  ✓ Python3 已安装"
elif command -v python2 &> /dev/null; then
    PYTHON=python2
    echo "  ✓ Python2 已安装"
elif command -v python &> /dev/null; then
    PYTHON=python
    echo "  ✓ Python 已安装"
else
    echo "  ✗ 未找到 Python，正在安装..."
    if command -v yum &> /dev/null; then
        yum install -y python3 python3-pip
    elif command -v apt &> /dev/null; then
        apt update && apt install -y python3 python3-pip
    fi
    PYTHON=python3
fi

# 2. 安装 websockify
echo ""
echo "[2/5] 安装 websockify..."
if command -v websockify &> /dev/null; then
    echo "  ✓ websockify 已安装"
else
    echo "  正在安装 websockify..."
    if $PYTHON -m pip --version &> /dev/null; then
        # CentOS 7 上 Python 3.6 版本较旧，需要安装兼容版本的依赖
        PYTHON_VERSION=$($PYTHON -c 'import sys; print(sys.version_info.major * 10 + sys.version_info.minor)')
        if [ "$PYTHON_VERSION" -le 36 ]; then
            echo "  检测到 Python 3.6 或更低版本，安装兼容版本..."
            # 升级 pip 和 setuptools
            $PYTHON -m pip install --upgrade pip setuptools -i https://pypi.tuna.tsinghua.edu.cn/simple 2>/dev/null || true
            # 安装旧版本 cryptography（不需要 Rust）
            $PYTHON -m pip install "cryptography==3.3.2" "cffi>=1.12" -i https://pypi.tuna.tsinghua.edu.cn/simple 2>/dev/null || true
            # 安装旧版本 websockify
            $PYTHON -m pip install "websockify==0.10.0" numpy -i https://pypi.tuna.tsinghua.edu.cn/simple 2>/dev/null || \
            $PYTHON -m pip install websockify numpy -i https://pypi.tuna.tsinghua.edu.cn/simple 2>/dev/null || \
            $PYTHON -m pip install websockify numpy
        else
            $PYTHON -m pip install websockify numpy -i https://pypi.tuna.tsinghua.edu.cn/simple 2>/dev/null || \
            $PYTHON -m pip install websockify numpy
        fi
    elif command -v yum &> /dev/null; then
        yum install -y websockify
    elif command -v apt &> /dev/null; then
        apt update && apt install -y websockify
    else
        echo "  ✗ 无法安装 websockify，请手动安装：pip install websockify"
        exit 1
    fi
fi

WEBSOCKIFY_PATH=$(which websockify 2>/dev/null || echo "")
if [ -z "$WEBSOCKIFY_PATH" ]; then
    WEBSOCKIFY_BIN="$($PYTHON -c 'import websockify; print(websockify.__file__)' 2>/dev/null | xargs dirname)/websockify.py"
    if [ -f "$WEBSOCKIFY_BIN" ]; then
        WEBSOCKIFY_PATH="$PYTHON $WEBSOCKIFY_BIN"
    fi
fi
echo "  ✓ websockify 路径: $WEBSOCKIFY_PATH"

# 3. 下载 noVNC
echo ""
echo "[3/5] 下载 noVNC..."
if [ -f "$SCRIPT_DIR/rfb.js" ]; then
    echo "  ✓ noVNC rfb.js 已存在，跳过下载"
elif [ -f "/usr/share/novnc/app/rfb.js" ]; then
    echo "  ✓ 检测到系统已安装 noVNC，正在复制..."
    cp /usr/share/novnc/app/*.js "$SCRIPT_DIR/" 2>/dev/null || true
    cp -r /usr/share/novnc/app/styles "$SCRIPT_DIR/" 2>/dev/null || true
    cp /usr/share/novnc/vnc_lite.html "$SCRIPT_DIR/" 2>/dev/null || true
    echo "  ✓ noVNC 复制完成"
else
    NOVNC_VERSION="1.4.0"
    NOVNC_TAR="/tmp/novnc-$NOVNC_VERSION.tar.gz"

    echo "  正在下载 noVNC v$NOVNC_VERSION ..."

    # 尝试多个下载源
    download_ok=0
    for URL in \
        "https://cdn.npm.dog/@novnc/novnc@$NOVNC_VERSION" \
        "https://registry.npmmirror.com/@novnc/novnc/$NOVNC_VERSION" \
        "https://ghproxy.com/https://github.com/novnc/noVNC/archive/refs/tags/v$NOVNC_VERSION.tar.gz" \
        "https://mirror.ghproxy.com/https://github.com/novnc/noVNC/archive/refs/tags/v$NOVNC_VERSION.tar.gz" \
        "https://github.91cj.cf/https://github.com/novnc/noVNC/archive/refs/tags/v$NOVNC_VERSION.tar.gz" \
        "https://hub.fastgit.xyz/novnc/noVNC/archive/refs/tags/v$NOVNC_VERSION.tar.gz" \
        "https://github.com/novnc/noVNC/archive/refs/tags/v$NOVNC_VERSION.tar.gz" \
        "https://gitee.com/mirrors/noVNC/repository/archive/v$NOVNC_VERSION.tar.gz"
    do
        echo "  尝试: $URL"
        if curl -fsSL "$URL" -o "$NOVNC_TAR" --connect-timeout 10 --max-time 60 2>/dev/null; then
            if file "$NOVNC_TAR" | grep -q "gzip\|compressed"; then
                download_ok=1
                break
            fi
        fi
    done

    if [ $download_ok -eq 0 ]; then
        echo ""
        echo "  ═══════════════════════════════════════════"
        echo "  ⚠️  noVNC 下载失败，尝试 npm 方式安装..."
        echo "  ═══════════════════════════════════════════"

        # 尝试 npm 方式安装
        if command -v npm &> /dev/null; then
            echo "  使用 npm 安装 @novnc/novnc..."
            NPM_DIR="/tmp/novnc_npm_$NOVNC_VERSION"
            rm -rf "$NPM_DIR"
            mkdir -p "$NPM_DIR"
            cd "$NPM_DIR"

            if npm pack "@novnc/novnc@$NOVNC_VERSION" --registry https://registry.npmmirror.com 2>/dev/null; then
                NPM_TAR=$(ls *.tgz 2>/dev/null | head -1)
                if [ -n "$NPM_TAR" ]; then
                    tar -xzf "$NPM_TAR"
                    cp package/app/*.js "$SCRIPT_DIR/" 2>/dev/null || true
                    cp -r package/app/styles "$SCRIPT_DIR/" 2>/dev/null || true
                    cp package/vnc_lite.html "$SCRIPT_DIR/" 2>/dev/null || true
                    download_ok=1
                    cd /
                    rm -rf "$NPM_DIR"
                fi
            fi
        fi
    fi

    if [ $download_ok -eq 0 ]; then
        echo ""
        echo "  ═══════════════════════════════════════════════════════"
        echo "  ✗ noVNC 下载失败，请手动安装"
        echo "  ═══════════════════════════════════════════════════════"
        echo ""
        echo "  方法1 - GitHub 下载:"
        echo "    wget https://github.com/novnc/noVNC/archive/refs/tags/v1.4.0.tar.gz"
        echo "    tar -xzf v1.4.0.tar.gz"
        echo "    cp noVNC-1.4.0/app/*.js $SCRIPT_DIR/"
        echo "    cp -r noVNC-1.4.0/app/styles $SCRIPT_DIR/"
        echo ""
        echo "  方法2 - 使用 Docker:"
        echo "    docker run -d -p 6080:6080 -v \$PWD:/usr/share/novnc --name novnc novnc/novnc:latest"
        echo ""
        echo "  方法3 - 系统包管理器:"
        echo "    # CentOS/RHEL"
        echo "    yum install novnc"
        echo "    # Ubuntu/Debian"
        echo "    apt install novnc"
        echo ""
        echo "  下载后请将以下文件复制到: $SCRIPT_DIR/"
        echo "    rfb.js, webutil.js, ui.js, util.js, websock.js"
        echo "    keyboard.js, mouse.js, display.js, input.js"
        echo "    base64.js, des.js, inflator.js, keysym.js, keysymdef.js"
        echo ""
        read -p "按 Enter 键继续（将跳过 noVNC 部分）..."
    else
        echo "  解压中..."
        tar -xzf "$NOVNC_TAR" -C /tmp/ 2>/dev/null || true
        NOVNC_SRC="/tmp/noVNC-$NOVNC_VERSION"

        # 复制所有 JS 文件
        if [ -d "$NOVNC_SRC/app" ]; then
            cp "$NOVNC_SRC/app/"*.js "$SCRIPT_DIR/" 2>/dev/null || true
            cp -r "$NOVNC_SRC/app/styles" "$SCRIPT_DIR/styles" 2>/dev/null || true
            cp "$NOVNC_SRC/vnc_lite.html" "$SCRIPT_DIR/vnc_lite.html" 2>/dev/null || true
        fi

        rm -f "$NOVNC_TAR"
        rm -rf "$NOVNC_SRC"

        if [ -f "$SCRIPT_DIR/rfb.js" ]; then
            echo "  ✓ noVNC 下载完成"
        else
            echo "  ⚠ noVNC 文件复制可能不完整，但继续安装..."
        fi
    fi
fi

# 4. 创建 token 目录和启动脚本
echo ""
echo "[4/5] 创建配置和服务脚本..."

mkdir -p "$TOKEN_DIR"
touch "$TOKEN_FILE"

# 创建启动脚本
cat > "$SCRIPT_DIR/start_websockify.sh" << 'SCRIPT_EOF'
#!/bin/bash
# websockify 启动脚本
# 使用 token 插件，支持多个 VNC 连接共享一个端口

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/websockify.pid"
LOG_FILE="$SCRIPT_DIR/websockify.log"
TOKEN_FILE="$SCRIPT_DIR/tokens/tokens.conf"

WS_PORT=6080

if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
        echo "websockify 已经在运行 (PID: $OLD_PID)"
        exit 0
    fi
fi

echo "启动 websockify..."
echo "  监听端口: $WS_PORT"
echo "  Token 文件: $TOKEN_FILE"

mkdir -p "$SCRIPT_DIR/tokens"
touch "$TOKEN_FILE"

# 启动 websockify
nohup websockify \
    --web "$SCRIPT_DIR" \
    --daemon \
    --pid "$PID_FILE" \
    --log-file "$LOG_FILE" \
    --token-plugin TokenFile \
    --token-source "$TOKEN_FILE" \
    0.0.0.0:$WS_PORT 2>&1 &

sleep 1

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "✓ websockify 启动成功 (PID: $PID)"
        echo "  日志文件: $LOG_FILE"
        echo ""
        echo "  测试访问: http://你的域名/novnc/vnc.php?id=主机ID"
        exit 0
    fi
fi

echo "✗ websockify 启动失败"
tail -30 "$LOG_FILE" 2>/dev/null
exit 1
SCRIPT_EOF

# 创建停止脚本
cat > "$SCRIPT_DIR/stop_websockify.sh" << 'SCRIPT_EOF'
#!/bin/bash
# 停止 websockify

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/websockify.pid"

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "停止 websockify (PID: $PID)..."
        kill "$PID"
        sleep 1
        if kill -0 "$PID" 2>/dev/null; then
            kill -9 "$PID"
        fi
        echo "✓ 已停止"
    else
        echo "websockify 未运行"
    fi
    rm -f "$PID_FILE"
else
    echo "websockify 未运行 (PID 文件不存在)"
fi
SCRIPT_EOF

# 创建状态脚本
cat > "$SCRIPT_DIR/status_websockify.sh" << 'SCRIPT_EOF'
#!/bin/bash
# 查看 websockify 状态

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/websockify.pid"
LOG_FILE="$SCRIPT_DIR/websockify.log"

echo "websockify 状态:"
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "  运行中 (PID: $PID)"
        echo "  监听端口: 6080"
        echo ""
        echo "最近日志:"
        tail -10 "$LOG_FILE" 2>/dev/null
    else
        echo "  未运行 (PID 文件存在但进程不存在)"
    fi
else
    echo "  未运行"
fi
SCRIPT_EOF

chmod +x "$SCRIPT_DIR/start_websockify.sh"
chmod +x "$SCRIPT_DIR/stop_websockify.sh"
chmod +x "$SCRIPT_DIR/status_websockify.sh"

echo "  ✓ 服务脚本已创建"

# 5. 配置防火墙
echo ""
echo "[5/5] 配置防火墙（如需要）..."
if command -v firewall-cmd &> /dev/null; then
    firewall-cmd --zone=public --add-port=6080/tcp --permanent 2>/dev/null && \
    firewall-cmd --reload 2>/dev/null && \
    echo "  ✓ firewalld 端口 6080 已开放" || \
    echo "  - firewalld 配置失败（可能无需配置）"
elif command -v ufw &> /dev/null; then
    ufw allow 6080/tcp 2>/dev/null && \
    echo "  ✓ UFW 端口 6080 已开放" || \
    echo "  - UFW 配置失败"
else
    echo "  - 未检测到防火墙，请手动开放 6080 端口"
fi

echo ""
echo "========================================"
echo "  安装完成！"
echo "========================================"
echo ""
echo "常用命令："
echo "  启动: bash $SCRIPT_DIR/start_websockify.sh"
echo "  停止: bash $SCRIPT_DIR/stop_websockify.sh"
echo "  状态: bash $SCRIPT_DIR/status_websockify.sh"
echo ""
echo "使用方式："
echo "  1. 启动 websockify"
echo "  2. 确保虚拟机已开机"
echo "  3. 在主机控制台点击 \"VNC 控制台\" 按钮"
echo ""
echo "Token 文件: $TOKEN_FILE"
echo "  格式: token_name: 127.0.0.1:5900"
echo ""
