<?php
require_once __DIR__ . '/../config/helper.php';
require_auth();
session_write_close();

header('Content-Type: application/json');

$action = $_GET['action'] ?? 'check';

function check_websockify() {
    $result = [];
    
    $output = [];
    $return_var = 0;
    exec('ps aux | grep websockify | grep -v grep', $output, $return_var);
    
    if ($return_var === 0 && !empty($output)) {
        $result['running'] = true;
        $result['process'] = $output;
        foreach ($output as $line) {
            if (preg_match('/--web\s+(\S+)/', $line, $m)) {
                $result['web_dir'] = $m[1];
            }
            if (preg_match('/--token-source\s+(\S+)/', $line, $m)) {
                $result['token_file'] = $m[1];
            }
            if (preg_match('/(\d+\.\d+\.\d+\.\d+:)?(\d+)$/', $line, $m)) {
                $result['listen_port'] = $m[2];
            }
        }
    } else {
        $result['running'] = false;
        $result['error'] = 'websockify 未运行';
    }
    
    return $result;
}

function check_port($port) {
    $output = [];
    $return_var = 0;
    
    exec("ss -tlnp 2>/dev/null | grep -E ':$port\\b'", $output, $return_var);
    if ($return_var === 0 && !empty($output)) {
        return true;
    }
    
    exec("netstat -tlnp 2>/dev/null | grep -E ':$port\\b'", $output, $return_var);
    if ($return_var === 0 && !empty($output)) {
        return true;
    }
    
    return false;
}

function check_token_file($token_file) {
    $result = [
        'exists' => false,
        'path' => $token_file,
        'entries' => [],
        'count' => 0,
    ];
    
    if (file_exists($token_file)) {
        $result['exists'] = true;
        $content = file_get_contents($token_file);
        $lines = array_filter(explode("\n", $content));
        $result['count'] = count($lines);
        
        foreach ($lines as $line) {
            if (preg_match('/^([a-f0-9]+):\s+127\.0\.0\.1:(\d+)/', trim($line), $m)) {
                $result['entries'][] = [
                    'token' => $m[1],
                    'port' => intval($m[2]),
                ];
            }
        }
    }
    
    return $result;
}

function check_kvm_vm($vm_name) {
    $result = [
        'exists' => false,
        'state' => 'unknown',
        'vnc_port' => '',
        'vnc_display' => '',
        'vnc_listen' => '',
        'error' => '',
        'qemu_process' => '',
        'xml_graphics' => '',
    ];
    
    try {
        $kvm = kvm_get_manager();
        
        $list = $kvm->listVMs();
        if (strpos($list, $vm_name) !== false) {
            $result['exists'] = true;
            $result['state'] = $kvm->getVMPowerState($vm_name);
            
            if ($result['state'] === 'running') {
                $vnc_display = $kvm->getVNCDisplay($vm_name);
                $result['vnc_display'] = $vnc_display;
                
                if (strpos($vnc_display, ':') === 0) {
                    $result['vnc_port'] = 5900 + intval(substr($vnc_display, 1));
                } else if (is_numeric($vnc_display)) {
                    $result['vnc_port'] = intval($vnc_display);
                }
                
                $xml = $kvm->getDomainXML($vm_name);
                if ($xml) {
                    if (preg_match('/<graphics[^>]*type=[\'"]vnc[\'"][^>]*>(?:\s*<listen[^>]*>\s*<\/graphics>)?/s', $xml, $m)) {
                        $result['xml_graphics'] = htmlspecialchars($m[0]);
                        if (preg_match('/listen=[\'"]([^\'"]+)/', $m[0], $lm)) {
                            $result['vnc_listen'] = $lm[1];
                        }
                        if (preg_match('/address=[\'"]([^\'"]+)/', $m[0], $am)) {
                            $result['vnc_listen'] = $am[1];
                        }
                    }
                }
                
                $output = [];
                exec("ps aux | grep qemu | grep -i " . escapeshellarg($vm_name), $output);
                if (!empty($output)) {
                    $result['qemu_process'] = $output[0];
                }
            }
        } else {
            $result['error'] = "虚拟机 $vm_name 不存在于 libvirt";
        }
    } catch (Exception $e) {
        $result['error'] = $e->getMessage();
    }
    
    return $result;
}

function check_vnc_port_listening($port) {
    $output = [];
    $return_var = 0;
    
    exec("ss -tlnp 2>/dev/null | grep -E ':$port\\b'", $output, $return_var);
    if ($return_var === 0 && !empty($output)) {
        return [
            'listening' => true,
            'detail' => implode("\n", $output),
        ];
    }
    
    exec("netstat -tlnp 2>/dev/null | grep -E ':$port\\b'", $output, $return_var);
    if ($return_var === 0 && !empty($output)) {
        return [
            'listening' => true,
            'detail' => implode("\n", $output),
        ];
    }
    
    $connection = @fsockopen('127.0.0.1', $port, $errno, $errstr, 2);
    if ($connection) {
        fclose($connection);
        return [
            'listening' => true,
            'detail' => '通过fsockopen检测到端口开放',
        ];
    }
    
    return [
        'listening' => false,
        'detail' => '',
    ];
}

function check_firewall($port) {
    $result = [
        'rules' => [],
        'status' => 'unknown',
    ];
    
    $output = [];
    exec('firewall-cmd --list-ports 2>/dev/null', $output, $return_var);
    if ($return_var === 0) {
        $ports = explode(' ', trim(implode(' ', $output)));
        $result['rules'] = $ports;
        $result['status'] = in_array("$port/tcp", $ports) ? 'allowed' : 'not_found';
    } else {
        exec('iptables -L -n 2>/dev/null | grep ' . $port, $output, $return_var);
        if ($return_var === 0) {
            $result['rules'] = $output;
            $result['status'] = 'iptables_rule';
        }
    }
    
    return $result;
}

function create_token($vm_name, $vnc_port) {
    $token = md5($vm_name . '_' . $vnc_port . '_' . time());
    $token_dir = __DIR__ . '/tokens';
    $token_map = $token_dir . '/tokens.conf';
    
    if (!is_dir($token_dir)) {
        mkdir($token_dir, 0755, true);
    }
    
    $content = '';
    if (file_exists($token_map)) {
        $content = file_get_contents($token_map);
    }
    
    $new_entry = $token . ': 127.0.0.1:' . $vnc_port . "\n";
    
    $lines = [];
    if (!empty($content)) {
        $lines = array_filter(explode("\n", $content));
    }
    
    $found = false;
    foreach ($lines as &$line) {
        if (strpos($line, '127.0.0.1:' . $vnc_port) !== false) {
            $line = trim($new_entry);
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        $lines[] = trim($new_entry);
    }
    
    file_put_contents($token_map, implode("\n", array_filter($lines)) . "\n");
    
    return $token;
}

function restart_websockify() {
    $output = [];
    $return_var = 0;
    
    exec('systemctl restart websockify 2>&1', $output, $return_var);
    if ($return_var === 0) {
        sleep(2);
        $ws_check = check_websockify();
        return [
            'success' => $ws_check['running'],
            'message' => 'websockify 已重启',
            'websockify' => $ws_check,
        ];
    }
    
    exec('pkill -f websockify 2>&1', $output, $return_var);
    sleep(1);
    
    $web_dir = '/www/wwwroot/' . $_SERVER['HTTP_HOST'] . '/novnc';
    $token_file = $web_dir . '/tokens/tokens.conf';
    
    $cmd = "nohup /usr/bin/python3 /usr/local/bin/websockify --web $web_dir --token-plugin TokenFile --token-source $token_file 0.0.0.0:6080 > /tmp/websockify.log 2>&1 &";
    exec($cmd, $output, $return_var);
    
    sleep(2);
    
    $ws_check = check_websockify();
    return [
        'success' => $ws_check['running'],
        'message' => $return_var === 0 ? 'websockify 已手动启动' : '重启失败',
        'websockify' => $ws_check,
    ];
}

switch ($action) {
    case 'full':
        $vm_name = $_GET['vm_name'] ?? '';
        $vnc_port = intval($_GET['vnc_port'] ?? 0);
        
        $websockify = check_websockify();
        $port6080 = check_port(6080);
        $token_file = $websockify['token_file'] ?? (__DIR__ . '/tokens/tokens.conf');
        $tokens = check_token_file($token_file);
        
        $kvm_vm = [];
        $vnc_listening = [];
        if ($vm_name) {
            $kvm_vm = check_kvm_vm($vm_name);
            if ($kvm_vm['vnc_port']) {
                $display = trim($kvm_vm['vnc_port']);
                if (strpos($display, ':') === 0) {
                    $vnc_port_num = 5900 + intval(substr($display, 1));
                    $vnc_listening = check_vnc_port_listening($vnc_port_num);
                } else if (is_numeric($display)) {
                    $vnc_listening = check_vnc_port_listening(intval($display));
                }
            }
        }
        
        $firewall = check_firewall(6080);
        
        $result = [
            'success' => true,
            'websockify' => $websockify,
            'port_6080' => [
                'listening' => $port6080,
            ],
            'token_file' => $tokens,
            'kvm_vm' => $kvm_vm,
            'vnc_listening' => $vnc_listening,
            'firewall' => $firewall,
        ];
        break;
    
    case 'create_token':
        $vm_name = $_POST['vm_name'] ?? '';
        $vnc_port = intval($_POST['vnc_port'] ?? 0);
        
        if (!$vm_name || !$vnc_port) {
            $result = ['success' => false, 'message' => '参数不足'];
            break;
        }
        
        $token = create_token($vm_name, $vnc_port);
        $result = [
            'success' => true,
            'token' => $token,
            'vnc_port' => $vnc_port,
        ];
        break;
    
    case 'restart_websockify':
        $result = restart_websockify();
        break;
    
    case 'check_vm':
        $vm_name = $_GET['vm_name'] ?? '';
        $result = check_kvm_vm($vm_name);
        break;
    
    default:
        $result = ['success' => false, 'message' => '未知操作'];
}

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>