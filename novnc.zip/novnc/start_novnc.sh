#!/bin/bash

NOVNC_DIR=$(cd "$(dirname "$0")" && pwd)
VNC_HOST=${VNC_HOST:-127.0.0.1}
NOVNC_PORT=${NOVNC_PORT:-6080}

echo "======================================"
echo "  noVNC 服务启动脚本"
echo "======================================"
echo "  noVNC目录: $NOVNC_DIR"
echo "  监听端口: $NOVNC_PORT"
echo "======================================"

if command -v websockify &> /dev/null; then
    echo "[OK] websockify 已安装"
else
    echo "[WARN] websockify 未安装，正在安装..."
    pip install websockify
    if [ $? -ne 0 ]; then
        echo "[ERROR] 安装失败，请手动安装: pip install websockify"
        exit 1
    fi
fi

echo "[INFO] 启动 noVNC + websockify..."
echo "[INFO] 访问地址: http://localhost:$NOVNC_PORT/vnc.html"

cd "$NOVNC_DIR"
websockify --web "$NOVNC_DIR" "$NOVNC_PORT" "$VNC_HOST:5900"

echo "[INFO] 服务已停止"