<?php
set_time_limit(0);
ini_set('memory_limit', '-1');

// 释放Session锁，WebSocket长连接会阻塞同用户其他请求
@session_write_close();

$target_host = isset($_GET['host']) ? $_GET['host'] : '127.0.0.1';
$target_port = isset($_GET['port']) ? intval($_GET['port']) : 5900;

$headers = getallheaders();

if (!isset($headers['Upgrade']) || $headers['Upgrade'] !== 'websocket') {
    header('HTTP/1.1 400 Bad Request');
    echo 'Expected WebSocket upgrade';
    exit;
}

$sec_key = $headers['Sec-WebSocket-Key'] ?? '';
$sec_accept = base64_encode(sha1($sec_key . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true));

header('HTTP/1.1 101 Switching Protocols');
header('Upgrade: websocket');
header('Connection: Upgrade');
header("Sec-WebSocket-Accept: $sec_accept");

$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_set_option($socket, SOL_SOCKET, SO_RCVTIMEO, ['sec' => 60, 'usec' => 0]);
socket_set_option($socket, SOL_SOCKET, SO_SNDTIMEO, ['sec' => 60, 'usec' => 0]);

$result = socket_connect($socket, $target_host, $target_port);
if (!$result) {
    header('HTTP/1.1 503 Service Unavailable');
    echo 'Failed to connect to VNC server';
    exit;
}

$client_socket = socket_create_listen(0);
socket_set_nonblock($client_socket);

$read_sockets = [$client_socket, $socket];
$write_sockets = [];
$except_sockets = [];

while (true) {
    $read = $read_sockets;
    $write = $write_sockets;
    $except = $except_sockets;
    
    $num_changed = socket_select($read, $write, $except, null);
    
    if ($num_changed === false) {
        break;
    }
    
    foreach ($read as $sock) {
        if ($sock === $socket) {
            $data = socket_read($socket, 65536);
            if ($data === false || $data === '') {
                break 2;
            }
            
            $frame = websocket_encode($data);
            echo $frame;
            flush();
        }
    }
    
    $input = '';
    $buffer = fread(STDIN, 65536);
    
    if ($buffer === false || $buffer === '') {
        break;
    }
    
    $input .= $buffer;
    
    while (strlen($input) > 0) {
        $frame = websocket_decode($input);
        if ($frame === null) {
            break;
        }
        
        socket_write($socket, $frame);
        
        $input = substr($input, strlen($frame) + 2);
    }
}

socket_close($socket);

function websocket_encode($data) {
    $length = strlen($data);
    $frame = '';
    
    if ($length <= 125) {
        $frame = chr(0x81) . chr($length);
    } elseif ($length <= 65535) {
        $frame = chr(0x81) . chr(126) . chr(($length >> 8) & 0xFF) . chr($length & 0xFF);
    } else {
        $frame = chr(0x81) . chr(127);
        for ($i = 7; $i >= 0; $i--) {
            $frame .= chr(($length >> ($i * 8)) & 0xFF);
        }
    }
    
    return $frame . $data;
}

function websocket_decode(&$data) {
    if (strlen($data) < 2) {
        return null;
    }
    
    $opcode = ord($data[0]) & 0x0F;
    $fin = ord($data[0]) & 0x80;
    $masked = ord($data[1]) & 0x80;
    $payload_length = ord($data[1]) & 0x7F;
    
    $offset = 2;
    
    if ($payload_length === 126) {
        if (strlen($data) < 4) {
            return null;
        }
        $payload_length = (ord($data[2]) << 8) | ord($data[3]);
        $offset = 4;
    } elseif ($payload_length === 127) {
        if (strlen($data) < 10) {
            return null;
        }
        $payload_length = 0;
        for ($i = 0; $i < 8; $i++) {
            $payload_length = ($payload_length << 8) | ord($data[$offset + $i]);
        }
        $offset = 10;
    }
    
    if ($masked) {
        if (strlen($data) < $offset + 4 + $payload_length) {
            return null;
        }
        
        $mask = substr($data, $offset, 4);
        $offset += 4;
        
        $payload = substr($data, $offset, $payload_length);
        
        for ($i = 0; $i < $payload_length; $i++) {
            $payload[$i] = chr(ord($payload[$i]) ^ ord($mask[$i % 4]));
        }
    } else {
        if (strlen($data) < $offset + $payload_length) {
            return null;
        }
        $payload = substr($data, $offset, $payload_length);
    }
    
    $data = substr($data, $offset + $payload_length);
    
    return $payload;
}
?>