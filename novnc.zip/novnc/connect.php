<?php
require_once __DIR__ . '/../config/helper.php';
require_auth();
session_write_close();

$id_param = $_GET['id'] ?? '';
$user_id = auth_id();

$host = null;
if (is_numeric($id_param)) {
    $id = intval($id_param);
    $host = Database::fetch("SELECT * FROM hosts WHERE id = ? AND user_id = ?", [$id, $user_id]);
} else {
    $uuid = $id_param;
    $host = Database::fetch("SELECT * FROM hosts WHERE uuid = ? AND user_id = ?", [$uuid, $user_id]);
}

if (!$host) {
    die('主机不存在');
}

$id = $host['id'];
$host_uuid = $host['uuid'] ?? $id;

if (empty($host['vm_name'])) {
    die('非KVM主机');
}

$vm_name = $host['vm_name'];

$kvm_cfg = config('kvm');
$vnc_host = $kvm_cfg['vnc_proxy_host'] ?? '127.0.0.1';
$public_domain = $kvm_cfg['public_domain'] ?? '';
$novnc_port = $kvm_cfg['novnc_port'] ?? 6080;

$vnc_port = 5900;
$vm_status = 'unknown';

if (kvm_is_enabled()) {
    try {
        $kvm = kvm_get_manager();
        $vm_status = $kvm->getVMPowerState($vm_name);
        
        if ($vm_status === 'running') {
            $vnc_display = $kvm->getVNCDisplay($vm_name);
            
            if (strpos($vnc_display, ':') === 0) {
                $vnc_port = 5900 + intval(substr($vnc_display, 1));
            } else if (is_numeric($vnc_display)) {
                $vnc_port = intval($vnc_display);
            }
        }
    } catch (Exception $e) {
        $vm_status = 'error';
    }
}

$display_vnc_host = $public_domain ?: $vnc_host;

$novnc_url = "http://{$display_vnc_host}:{$novnc_port}/vnc.html?host={$display_vnc_host}&port={$novnc_port}&autoconnect=true&resize=scale";

$websockify_running = false;
$fp = @fsockopen($display_vnc_host, $novnc_port, $errno, $errstr, 2);
if ($fp) {
    $websockify_running = true;
    fclose($fp);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VNC 连接 - <?php echo e($vm_name); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            padding: 40px 20px;
            color: #fff;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        h1 {
            font-size: 24px;
            text-align: center;
            margin-bottom: 30px;
        }
        .info-box {
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .info-row:last-child { border-bottom: none; }
        .info-label { color: rgba(255,255,255,0.6); }
        .info-value { font-weight: 600; }
        .status-running { color: #52c41a; }
        .status-stopped { color: #f5222d; }
        .status-available { color: #52c41a; }
        .status-unavailable { color: #f5222d; }
        
        .method-card {
            background: rgba(255,255,255,0.05);
            border: 2px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 16px;
            transition: all 0.3s;
        }
        .method-card:hover {
            border-color: rgba(22,119,255,0.5);
            background: rgba(22,119,255,0.1);
        }
        .method-card.disabled {
            opacity: 0.5;
            pointer-events: none;
        }
        .method-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }
        .method-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        .method-icon.green { background: rgba(82,196,26,0.2); }
        .method-icon.blue { background: rgba(22,119,255,0.2); }
        .method-icon.gray { background: rgba(134,144,156,0.2); }
        .method-title { font-size: 18px; font-weight: 600; }
        .method-desc { font-size: 13px; color: rgba(255,255,255,0.6); }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 14px 24px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: all 0.3s;
            width: 100%;
            margin-top: 16px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1677ff, #0958d9);
            color: #fff;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(22,119,255,0.4);
        }
        .btn-success {
            background: linear-gradient(135deg, #52c41a, #389e0d);
            color: #fff;
        }
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(82,196,26,0.4);
        }
        .btn-secondary {
            background: rgba(255,255,255,0.1);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.2);
        }
        
        .copy-box {
            background: rgba(0,0,0,0.3);
            border-radius: 8px;
            padding: 16px;
            font-family: monospace;
            font-size: 14px;
            word-break: break-all;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 12px;
        }
        .copy-btn {
            background: #1677ff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            white-space: nowrap;
        }
        .copy-btn:hover { background: #0958d9; }
        
        .notice {
            margin-top: 20px;
            padding: 16px;
            background: rgba(250,173,20,0.15);
            border-radius: 10px;
            font-size: 13px;
            color: #faad14;
            border-left: 4px solid #faad14;
        }
        .notice strong { display: block; margin-bottom: 8px; }
        
        .warning-box {
            background: rgba(245,34,45,0.15);
            border: 1px solid rgba(245,34,45,0.3);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            margin: 20px 0;
        }
        .warning-box .icon { font-size: 48px; margin-bottom: 16px; }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: rgba(255,255,255,0.6);
            text-decoration: none;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .back-link:hover { color: #fff; }
        
        .terminal-code {
            background: rgba(0,0,0,0.5);
            border-radius: 8px;
            padding: 12px;
            font-family: monospace;
            font-size: 12px;
            margin-top: 8px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="/user/host_kvm.php?id=<?php echo $host_uuid; ?>" class="back-link">← 返回主机控制台</a>
        
        <h1>🖥️ VNC 连接 - <?php echo e($vm_name); ?></h1>
        
        <div class="info-box">
            <div class="info-row">
                <span class="info-label">虚拟机名称</span>
                <span class="info-value"><?php echo e($vm_name); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">VNC 主机</span>
                <span class="info-value"><?php echo e($display_vnc_host); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">VNC 端口</span>
                <span class="info-value"><?php echo $vnc_port; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">虚拟机状态</span>
                <span class="info-value status-<?php echo $vm_status; ?>">
                    <?php 
                    switch($vm_status) {
                        case 'running': echo '🟢 运行中'; break;
                        case 'stopped': echo '🔴 已停止'; break;
                        case 'shut off': echo '⚫ 已关机'; break;
                        case 'paused': echo '🟡 已暂停'; break;
                        default: echo '⚠️ 未知'; break;
                    }
                    ?>
                </span>
            </div>
            <div class="info-row">
                <span class="info-label">noVNC服务</span>
                <span class="info-value <?php echo $websockify_running ? 'status-available' : 'status-unavailable'; ?>">
                    <?php echo $websockify_running ? '🟢 可用' : '� 未运行'; ?>
                </span>
            </div>
        </div>
        
        <?php if ($vm_status !== 'running'): ?>
            <div class="warning-box">
                <div class="icon">⚠️</div>
                <h3>虚拟机未运行</h3>
                <p style="color:rgba(255,255,255,0.6); margin-bottom:20px;">无法连接VNC，请先启动虚拟机</p>
                <a href="/user/host_kvm.php?id=<?php echo $host_uuid; ?>" class="btn btn-success">
                    ⚡ 启动虚拟机
                </a>
            </div>
        <?php else: ?>
        
        <?php if ($websockify_running): ?>
            <div class="method-card">
                <div class="method-header">
                    <div class="method-icon green">🌐</div>
                    <div>
                        <div class="method-title">网页连接 (推荐)</div>
                        <div class="method-desc">无需安装软件，浏览器直接访问</div>
                    </div>
                </div>
                <p style="font-size:14px; color:rgba(255,255,255,0.7);">
                    点击下方按钮在新窗口打开VNC控制台，支持鼠标和键盘操作
                </p>
                <a href="<?php echo e($novnc_url); ?>" target="_blank" class="btn btn-success">
                    🌐 打开 noVNC 控制台
                </a>
            </div>
        <?php endif; ?>
        
        <div class="method-card">
            <div class="method-header">
                <div class="method-icon blue">💻</div>
                <div>
                    <div class="method-title">VNC客户端连接</div>
                    <div class="method-desc">使用本地软件连接，更稳定</div>
                </div>
            </div>
            <p style="font-size:14px; color:rgba(255,255,255,0.7);">
                复制连接信息，使用本地VNC客户端软件连接
            </p>
            
            <div class="copy-box">
                <span><?php echo e($display_vnc_host); ?>:<?php echo $vnc_port; ?></span>
                <button class="copy-btn" onclick="copyToClipboard('<?php echo e($display_vnc_host); ?>:<?php echo $vnc_port; ?>')">📋 复制</button>
            </div>
            
            <div style="margin-top:16px;">
                <h4 style="margin-bottom:12px; color:#52c41a;">💻 推荐VNC客户端</h4>
                <ul style="list-style:none; padding:0; margin:0;">
                    <li style="padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.1);">
                        <strong>TightVNC</strong> (Windows) - 轻量级，免费
                    </li>
                    <li style="padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.1);">
                        <strong>RealVNC</strong> (全平台) - 功能丰富
                    </li>
                    <li style="padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.1);">
                        <strong>UltraVNC</strong> (Windows) - 支持插件
                    </li>
                    <li style="padding:8px 0;">
                        <strong>Remmina</strong> (Linux) - 集成多种协议
                    </li>
                </ul>
            </div>
        </div>
        
        <?php if (!$websockify_running): ?>
            <div class="notice">
                <strong>⚠️ noVNC服务未运行</strong>
                <p>网页连接功能需要启动websockify服务。请在服务器上执行以下命令：</p>
                <div class="terminal-code">
                    # 安装websockify<br>
                    pip install websockify<br>
                    <br>
                    # 启动服务（替换为实际路径）<br>
                    cd /www/wwwroot/192.168.3.2_4561/novnc<br>
                    websockify --web . 6080 localhost:5900
                </div>
                <p style="margin-top:8px;">启动后刷新此页面即可使用网页连接功能。</p>
            </div>
        <?php endif; ?>
        
        <?php endif; ?>
    </div>
    
    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('已复制到剪贴板: ' + text);
            }).catch(function() {
                var textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                alert('已复制到剪贴板: ' + text);
            });
        }
    </script>
</body>
</html>