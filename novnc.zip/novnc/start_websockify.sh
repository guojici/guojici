#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/websockify.pid"
LOG_FILE="$SCRIPT_DIR/websockify.log"
TOKEN_FILE="$SCRIPT_DIR/tokens/tokens.conf"
WS_PORT=6080

if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
        echo "websockify 已经在运行 (PID: $OLD_PID)"
        exit 0
    fi
fi

echo "启动 websockify..."
echo "  监听端口: $WS_PORT"
echo "  Token 文件: $TOKEN_FILE"

mkdir -p "$SCRIPT_DIR/tokens"
touch "$TOKEN_FILE"

# 使用 nohup 后台启动
nohup websockify \
    --web "$SCRIPT_DIR" \
    --token-plugin TokenFile \
    --token-source "$TOKEN_FILE" \
    0.0.0.0:$WS_PORT > "$LOG_FILE" 2>&1 &

echo $! > "$PID_FILE"
sleep 2

PID=$(cat "$PID_FILE")
if kill -0 "$PID" 2>/dev/null; then
    echo "✓ websockify 启动成功 (PID: $PID)"
    echo "  日志文件: $LOG_FILE"
    echo ""
    echo "  访问地址: http://你 的域名/novnc/vnc.php?id=主机ID"
    exit 0
else
    echo "✗ websockify 启动失败"
    tail -30 "$LOG_FILE" 2>/dev/null
    exit 1
fi
